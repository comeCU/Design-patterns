package com.dong.xmlrpc;

/**
 * 
 * @ClassName: HelloHandler 
 * @Description: ҵ��ӿ�ʵ��
 * @author: dong
 * @date: 2018��11��11�� ����3:27:10 
 * @keyword: 
 *
 */
public class HelloHandler implements ServicesHandler {

    public String sayHello(String str) {
        // TODO Auto-generated method stub
        return "hello " + str + "!";
    }

    public int add(int num1, int num2) {
        // TODO Auto-generated method stub
        return num1 + num2;
    }
    
    

}
