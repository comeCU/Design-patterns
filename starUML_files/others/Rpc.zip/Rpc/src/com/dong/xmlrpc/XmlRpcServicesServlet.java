package com.dong.xmlrpc;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.server.PropertyHandlerMapping;
import org.apache.xmlrpc.server.XmlRpcServerConfigImpl;
import org.apache.xmlrpc.webserver.XmlRpcServletServer;

/**
 * 
 * @ClassName: XmlRpcServicesServlet 
 * @Description: �����
 * @author: dong
 * @date: 2018��11��11�� ����3:28:09 
 * @keyword: 
 *
 */
public class XmlRpcServicesServlet extends HttpServlet {
	private XmlRpcServletServer  server;
	
    @Override
    public void init(ServletConfig config) throws ServletException {
        // TODO Auto-generated method stub
        super.init(config);
        
        try {
            // ����XmlRpcServicesServlet����
            server = new XmlRpcServletServer();
            
            //set up handler mapping of XmlRpcServletServer object
            PropertyHandlerMapping pmp = new PropertyHandlerMapping(); 
            pmp.addHandler("HelloHandler", HelloHandler.class);
            server.setHandlerMapping(pmp);
            
            //more config of XmlRpcServletServer object
            XmlRpcServerConfigImpl serverConfig = (XmlRpcServerConfigImpl) server.getConfig();
            serverConfig.setEnabledForExceptions(true);
            serverConfig.setContentLengthOptional(false);
            
        } catch (XmlRpcException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }  
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        
        server.execute(request, response);
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	    server.execute(request, response);
	}

}
