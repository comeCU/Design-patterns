package com.dong.xmlrpc;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

/**
 * 
 * @ClassName: TestClient 
 * @Description: �ͻ���
 * @author dong 
 * @date Nov 6, 2018 10:02:43 PM 
 * @keywords : 
 *
 */
public class TestClient {

    public static void main(String[] args) {

        try {
            // ���ÿͻ���
            XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
            // ���÷���˵�ַ
            config.setServerURL(new URL("http://127.0.0.1:8080/Rpc/HelloHandler"));
            // ����XmlRpc�ͻ���
            XmlRpcClient client = new XmlRpcClient();
            // ����������
            client.setConfig(config);
            // ���������б�
            Vector<String> params1 = new Vector<String>();
            
            params1.addElement("dong");
            
            Object[] params2 = new Object[2];
            params2[0] = 23;
            params2[1] = 20; 
            
            // ִ��xml-rpc����
            String result1 = (String) client.execute("HelloHandler.sayHello", params1);
            System.out.println("reslut:" + result1);
            
            int result2 = (Integer) client.execute("HelloHandler.add", params2);
            
            System.out.println("result:" + result2);
            
            
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (XmlRpcException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }

}
